rootProject.name = "video_player_android"
